lesson-1:缩略图

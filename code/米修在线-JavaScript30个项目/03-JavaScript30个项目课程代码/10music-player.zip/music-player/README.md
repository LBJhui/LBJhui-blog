lesson-6:进度条&歌曲切换
